//
//  ViewController.swift
//  TestProject
//
//  Created by USER on 24/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import UIKit

class ViewController: TestProjectBaseVC {

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // makes navigation bar clear
        self.navigationController?.navigationBar.makeClear()
        // make uibarbutton with menu or back
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.menuOrBackButton(self, action: #selector(writeYourAction), imageName: "Write Your Image Name")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationTitleImageView.removeFromSuperview()
    }
    
    
    @IBAction func nearByRestaurantTapped(_ sender: UIButton) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "RestaurantViewController") as! RestaurantViewController
        self.navigationController?.pushViewController(nextVc, animated: false)
    }
    

}

