//
//  RestaurantViewController.swift
//  TestProject
//
//  Created by USER on 24/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import UIKit
import CoreLocation



class RestaurantViewController: TestProjectBaseVC {

    @IBOutlet weak var restaurantsTblView: UITableView!
 
    var locationManager = CLLocationManager()
    lazy private var currentlatitude: Double = 0.0
    lazy private var currentlongitude: Double = 0.0
    lazy var restaurantsList = [Restaurants]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // MARK: - loader
        startAnimatingActivityIndicator()

        
        // to call the methods under cllocation
        locationManager.delegate = self
        // only when opens the app request the users current location
        locationManager.requestWhenInUseAuthorization()
        // starts updating the location by calling update location method
        locationManager.startUpdatingLocation()
        //request location
        locationManager.requestLocation()
        
        restaurantsTblView.register(UINib(nibName: "RestaurantTableViewCell", bundle: nil), forCellReuseIdentifier: "RestaurantTableViewCell")

        // Do any additional setup after loading the view.
    }
    
  
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.makeDefault("Near By Restaurants")
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.menuOrBackButton(self, action: #selector(backAction), imageName: "Back-white")
    }
    
    func fetchRestaurantsList(){
        
        RequestManager.shared.fetchRestaurants(currentLatitude: currentlatitude,currentLongitude: currentlongitude, completedSuccessfully: {[weak self] (restaurantsList) in
            print("Success")
            DispatchQueue.main.async {
                self?.stopAnimatingActivityIndicator()
                self?.restaurantsList = restaurantsList.restaurants ?? []
                self?.restaurantsTblView.reloadData()
            }
            
        }) { (error) in
            self.showAlert(withTitle: "Error", message: error.message, okHandler: { () -> Void? in
                return nil
            })
            self.stopAnimatingActivityIndicator()
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension RestaurantViewController : CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first, location.horizontalAccuracy >= 0 else { return }
        currentlatitude = location.coordinate.latitude
        currentlongitude = location.coordinate.longitude
        self.fetchRestaurantsList()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {

    }
}

extension RestaurantViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    
}

extension RestaurantViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RestaurantTableViewCell", for: indexPath) as? RestaurantTableViewCell
        cell?.restaurantNameLbl.text = restaurantsList[indexPath.row].restaurant?.name
        cell?.restaurantRating.text = restaurantsList[indexPath.row].restaurant?.user_rating?.aggregate_rating
        return cell!
    }
    
    
}
