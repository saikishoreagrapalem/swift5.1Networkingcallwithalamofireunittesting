//
//  NetworkConstants.swift
//  TestProject
//
//  Created by USER on 24/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//


import Foundation

struct NetworkConstants {
    
    static let baseUrl = "https://developers.zomato.com/api/v2.1/"
    
    struct EndPoints {
        
        static let sendOtp = NetworkConstants.baseUrl + "search?"
        
    }
    
    
}
