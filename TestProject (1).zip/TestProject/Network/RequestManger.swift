//
//  RequestManger.swift
//  TestProject
//
//  Created by USER on 24/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import Foundation
import Alamofire

class RequestManager {
    
    static let shared = RequestManager()
    
    private init(){
        
    }
    
    let httpHeader : HTTPHeaders = ["Accept": "application/json" ,"user-key": "915e38b5de9196013db29ad49d303257"]

    func fetchRestaurants(currentLatitude: Double, currentLongitude: Double, completedSuccessfully success: @escaping (RestaurantsList) -> Void, failedWithError failure: @escaping (TestProjectError)-> Void){
        let baseUrl = "https://developers.zomato.com/api/v2.1/search?"
        let EndPoint = "lat=\(currentLatitude)&lon=\(currentLongitude)&radius=500"
        let request = Alamofire.request(baseUrl + EndPoint, method: .post, parameters: nil, encoding: JSONEncoding.default, headers: httpHeader)
        RequestHandler.sendRequest(request: request, completedSuccessfully: { (data) in
            if let responseData = data {
                do {
                    let restaurantsList = try JSONDecoder().decode(RestaurantsList.self, from: responseData)
                    success(restaurantsList)
                } catch let error {
                    print(error.localizedDescription)
                    failure(TestProjectError(withType: .parsing))
                }
            } else {
                failure(TestProjectError(withType: TestProjectErrorType.parsing))
            }
        }) { (error) in
            failure(error)
        }
    }
    
}
