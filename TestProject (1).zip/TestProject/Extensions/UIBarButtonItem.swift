//
//  UIBarButtonItem.swift
//  TestProject
//
//  Created by USER on 24/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import UIKit

extension UIBarButtonItem {
    
    class func menuOrBackButton(_ target: Any?, action: Selector, imageName: String) -> UIBarButtonItem {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: imageName), for: .normal)
        button.addTarget(target, action: action, for: .touchUpInside)
        let menuBarItem = UIBarButtonItem(customView: button)
        menuBarItem.customView?.translatesAutoresizingMaskIntoConstraints = false
        menuBarItem.customView?.heightAnchor.constraint(equalToConstant: 24).isActive = true
        menuBarItem.customView?.widthAnchor.constraint(equalToConstant: 24).isActive = true
        return menuBarItem
    }
    
    
}
