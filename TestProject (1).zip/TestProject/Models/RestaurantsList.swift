//
//  RestaurantsList.swift
//  TestProject
//
//  Created by USER on 25/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import Foundation


class RestaurantsList: Codable {
    
    var results_found: Int?
    var restaurants: [Restaurants]?
   
    enum CodingKeys: String, CodingKey {
        case results_found = "results_found"
        case restaurants = "restaurants"
    }
    
}

class  Restaurants: Codable {

    var restaurant: RestaurantsName?

    
    enum CodingKeys: String, CodingKey {
        case restaurant = "restaurant"
    }
    
}

class  RestaurantsName: Codable {
    
    var name: String?
    var user_rating: UserRating?

    enum CodingKeys: String, CodingKey {
        case name = "name"
        case user_rating = "user_rating"

    }
    
}

class  UserRating: Codable {
    
    var aggregate_rating: String?
    
    enum CodingKeys: String, CodingKey {
        case aggregate_rating = "aggregate_rating"
    }
    
    init(aggregate_rating: String?) {
        self.aggregate_rating = aggregate_rating
    }
}
