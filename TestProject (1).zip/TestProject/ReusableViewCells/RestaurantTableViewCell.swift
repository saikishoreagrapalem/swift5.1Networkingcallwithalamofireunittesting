//
//  RestaurantTableViewCell.swift
//  TestProject
//
//  Created by USER on 25/10/19.
//  Copyright © 2019 Sai Kishore. All rights reserved.
//

import UIKit

class RestaurantTableViewCell: UITableViewCell {

    
    @IBOutlet weak var restaurantNameLbl: UILabel!
    @IBOutlet weak var restaurantRating: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
